module.exports = function (id, name, previewImage, image, order) {
  this.id = id
  this.name = name
  this.previewImage = previewImage
  this.image = image
  this.order = order
}
